/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CruiseDa;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.File; 
import java.io.IOException;
import java.util.*;


public class CruiseDa{

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
        Cabin cb = new Cabin();
        String menu = "";
        do {
                System.out.println("------------");
            System.out.println("Type in 'A' to add Passenger.");
            System.out.println("Type in 'V' to view Cabin.");
            System.out.println("Type in 'E' to show empty Cabin.");
            System.out.println("Type in 'D' to delete customer.");
            System.out.println("Type in 'F' to find customer through name.");
            System.out.println("Type in 'C' to Create file");
            System.out.println("Type in 'S' to store file.");
            System.out.println("Type in 'L' to load file");
            System.out.println("Type in 'O' to order names");
            System.out.println("Type in 'T' to view passenger expenses");
            System.out.println("Type in 'Q' to quit the program.");
            System.out.println("-----------------");
           
            Scanner input = new Scanner(System.in);
            menu = input.next();
            menu = menu.toUpperCase();
            switch(menu) {
                  case "A":                                                                                                     
                  cb.CabinAdd();
                    break;

                case "V":
                   System.out.println("The twelve cabins names are cabin1, cabin2, cabin3, cabin4, cabin5, cabin6, cabin7, cabin8, cabin9, cabin10, cabin11, cabin12");
                    break;
                
                case "E":                                                                                                     
                  cb.EmptyCabin();
                    break;
    
                case "D":                                                                                                     
                  cb.DeleteCustomer();
                    break;
                    
                case "F":                                                                                                     
                  cb.FindCustomer();
                    break;
                    
                case "C":                                                                                                     
                  cb.CreateFile();
                    break;
                    
                case "S":                                                                                                     
                 cb.StoreFile();
                    break;
                    
                case "L":                                                                                                     
                 cb.LoadFile();
                    break;
                    
                case "O":                                                                                                     
                  cb.NameOrder();
                    break;
                    
                 case "T":                                                                                               
                  cb.CustomerExpenses();
                    break;
                    
                case "Q":
                    System.exit(0);

                default:                                                                  
                    System.out.println("Incorrect, Please try again");
                    break;
            }
        } while (!menu.equals("Q"));                                  
        }  

   

    

    

    

    
    
   
}