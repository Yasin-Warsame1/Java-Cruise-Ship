/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CruiseDa;
import java.util.Comparator;


public class Passengers {
    
    private String FirstName;
    private String Surname;
    private Double Expenses;
    
    Passengers(String FName,String Sname,Double Exps){ 
    this.FirstName = FName;
    this.Surname = Sname;
    this.Expenses = Exps;
    }
    
    /**
     *
     * @return
     */
// Getter
    public String getFirstName() {
        return FirstName;
    }
    //Setter
    public void setFirstName(String newFirstName) {
        this.FirstName = newFirstName;
    }

    public String getSurname() {
        return Surname;
    }
    //Setter
    public void setSurname(String newSurname) {
        this.Surname = newSurname;
    }
    
    // Getter
    public Double getExpenses() {
        return Expenses;
    }
    //Setter
    public void setExpenses(Double newExpenses) {
        this.Expenses = newExpenses;
    }

 public static Comparator<Passengers> PassnameComparator = new Comparator<Passengers>() {

    public int compare(Passengers p1, Passengers p2) {
        
       String passengerName1 = p1.getFirstName().toUpperCase();
       String passengerName2 = p2.getFirstName().toUpperCase();

       if(passengerName1 == passengerName2){
       String passengerSurname1 = p1.getSurname().toUpperCase();
       String passengerSurname2 = p2.getSurname().toUpperCase();
       return passengerSurname1.compareTo(passengerSurname2);
       }
       
       return passengerName1.compareTo(passengerName2);

    }};
    
 @Override
    public String toString() {
        return " First name = " + FirstName.substring(0,1).toUpperCase() + FirstName.substring(1).toLowerCase() + " Surname = " + Surname.substring(0,1).toUpperCase() + Surname.substring(1).toLowerCase();
    }   
 
    
    
}
