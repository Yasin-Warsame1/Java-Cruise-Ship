/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CruiseDa;

//import static cruise2.Cruise2.FileName;
import java.io.FileInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;


public class Cabin {
    
    
    public static ArrayList<Passengers> Cabin1 = new ArrayList<>();
    public static ArrayList<Passengers> Cabin2 = new ArrayList<>();
    public static ArrayList<Passengers> Cabin3 = new ArrayList<>();
    public static ArrayList<Passengers> Cabin4 = new ArrayList<>();
    public static ArrayList<Passengers> Cabin5 = new ArrayList<>();
    public static ArrayList<Passengers> Cabin6 = new ArrayList<>();
    public static ArrayList<Passengers> Cabin7 = new ArrayList<>();
    public static ArrayList<Passengers> Cabin8 = new ArrayList<>();
    public static ArrayList<Passengers> Cabin9 = new ArrayList<>();
    public static ArrayList<Passengers> Cabin10 = new ArrayList<>();
    public static ArrayList<Passengers> Cabin11 = new ArrayList<>();
    public static ArrayList<Passengers> Cabin12 = new ArrayList<>();
    
     public static String FileName;
    
    public static void CabinAdd() {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter your First name:");
        String firstname = input.next();

        System.out.print("Enter your Last name:");
        String surname = input.next();
        
        System.out.print("Enter your expenses:");
        double expenses = input.nextDouble();
        if(Cabin1.size() < 3){
            Cabin1.add(new Passengers(firstname, surname, expenses));
            System.out.println("Passenger " + firstname + surname + " and their expenses has been added to Cabin1 ");
        }
        else if(Cabin2.size() < 3){
            Cabin2.add(new Passengers(firstname, surname, expenses));
            System.out.println("Passenger " + firstname + surname + " and their expenses has been added to Cabin2 ");
        }
        else if(Cabin3.size() < 3){
            Cabin3.add(new Passengers(firstname, surname, expenses));
            System.out.println("Passenger " + firstname + surname + " and their expenses has been added to Cabin3 ");
        }
        else if(Cabin4.size() < 3){
            Cabin4.add(new Passengers(firstname, surname, expenses));
            System.out.println("Passenger " + firstname + surname + " and their expenses has been added to Cabin4 ");
        }
        else if(Cabin5.size() < 3){
            Cabin5.add(new Passengers(firstname, surname, expenses));
            System.out.println("Passenger " + firstname + surname + " and their expenses has been added to Cabin5 ");
        }
        else if(Cabin6.size() < 3){
            Cabin6.add(new Passengers(firstname, surname, expenses));
            System.out.println("Passenger " + firstname + surname + " and their expenses has been added to Cabin6 ");
        }
        else if(Cabin7.size() < 3){
            Cabin7.add(new Passengers(firstname, surname, expenses));
            System.out.println("Passenger " + firstname + surname + " and their expenses has been added to Cabin7 ");
        }
        else if(Cabin8.size() < 3){
            Cabin8.add(new Passengers(firstname, surname, expenses));
            System.out.println("Passenger " + firstname + surname + " and their expenses has been added to Cabin8 ");
        }
        else if(Cabin9.size() < 3){
            Cabin9.add(new Passengers(firstname, surname, expenses));
            System.out.println("Passenger " + firstname + surname + " and their expenses has been added to Cabin9 ");
        }
        else if(Cabin10.size() < 3){
            Cabin10.add(new Passengers(firstname, surname, expenses));
            System.out.println("Passenger " + firstname + surname + " and their expenses has been added to Cabin10 ");
        }
        else if(Cabin11.size() < 3){
            Cabin11.add(new Passengers(firstname, surname, expenses));
            System.out.println("Passenger " + firstname + surname + " and their expenses has been added to Cabin11 ");
        }
        else if(Cabin12.size() < 3){
            Cabin12.add(new Passengers(firstname, surname, expenses));
            System.out.println("Passenger " + firstname + surname + " and their expenses has been added to Cabin12 ");
        }
    }

     public static void EmptyCabin() {
        System.out.print("The empty cabins are; ");
    if(Cabin1.size() == 0){
        System.out.print("Cabin1");
    }
    if(Cabin2.size() == 0){
        System.out.print("Cabin2");
    }
    if(Cabin3.size() == 0){
        System.out.print("Cabin3");
    }
    if(Cabin4.size() == 0){
        System.out.print("Cabin4");
    }
    if(Cabin5.size() == 0){
        System.out.print("Cabin5");
    }
    if(Cabin6.size() == 0){
        System.out.print("Cabin6");
    }
    if(Cabin7.size() == 0){
        System.out.print("Cabin7");
    }
    if(Cabin8.size() == 0){
        System.out.print("Cabin8");
    }
    if(Cabin9.size() == 0){
        System.out.print("Cabin9");
    }
    if(Cabin10.size() == 0){
        System.out.print("Cabin10");
    }
    if(Cabin11.size() == 0){
        System.out.print("Cabin11");
    }
    if(Cabin12.size() == 0){
        System.out.print("Cabin12");
    }
    }
    
    
   public static void DeleteCustomer(){
        if(Cabin12.size() > 0){
           int index = Cabin12.size() - 1;
           System.out.println(Cabin12.get(index) + " Has been removed from Cabin11");
           Cabin12.remove(index);
        }
        else if(Cabin11.size() > 0){
           int index = Cabin11.size() - 1;
           System.out.println(Cabin11.get(index) + " Has been removed from Cabin11");
           Cabin11.remove(index); 
        }
        else if(Cabin10.size() > 0){
           int index = Cabin10.size() - 1;
           System.out.println(Cabin10.get(index) + " Has been removed from Cabin10");
           Cabin10.remove(index); 
        }
        else if(Cabin9.size() > 0){
           int index = Cabin9.size() - 1;
           System.out.println(Cabin9.get(index) + " Has been removed from Cabin9");
           Cabin9.remove(index); 
        }
        else if(Cabin8.size() > 0){
           int index = Cabin8.size() - 1;
           System.out.println(Cabin8.get(index) + " Has been removed from Cabin8");
           Cabin8.remove(index); 
        }
        else if(Cabin7.size() > 0){
           int index = Cabin7.size() - 1;
           System.out.println(Cabin7.get(index) + " Has been removed from Cabin7");
           Cabin7.remove(index); 
        }
        else if(Cabin6.size() > 0){
           int index = Cabin6.size() - 1;
           System.out.println(Cabin6.get(index) + " Has been removed from Cabin6");
           Cabin6.remove(index); 
        }
        else if(Cabin5.size() > 0){
           int index = Cabin5.size() - 1;
           System.out.println(Cabin5.get(index) + " Has been removed from Cabin5");
           Cabin5.remove(index); 
        }
        else if(Cabin4.size() > 0){
           int index = Cabin4.size() - 1;
           System.out.println(Cabin4.get(index) + " Has been removed from Cabin4");
           Cabin4.remove(index); 
        }
        else if(Cabin3.size() > 0){
           int index = Cabin3.size() - 1;
           System.out.println(Cabin3.get(index) + " Has been removed from Cabin3");
           Cabin3.remove(index); 
        }
        else if(Cabin2.size() > 0){
           int index = Cabin2.size() - 1;
           System.out.println(Cabin2.get(index) + " Has been removed from Cabin2");
           Cabin2.remove(index); 
        }
        else if(Cabin1.size() > 0){
           int index = Cabin1.size() - 1;
           System.out.println(Cabin1.get(index) + " Has been removed from Cabin1");
           Cabin1.remove(index); 
        }
        else{
            System.out.println("All Cabins are empty");
        }
    }
    
        public static void CreateFile(){
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the name of your file:");
        FileName = input.next();
    try {
      File myObj = new File(FileName + ".txt");
      if (myObj.createNewFile()) {
        System.out.println("File created: " + myObj.getName());
      } else {
        System.out.println("File already exists.");
      }
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
    }
    
    public static void StoreFile(){
    try {
      FileWriter edit = new FileWriter(FileName + ".txt");
      if(Cabin1.size() > 0){
      edit.write("Cabin1 contains " + Cabin1 + " ");
      } else{
      edit.write("Cabin1 is empty ");
      }
      if(Cabin2.size() > 0){
      edit.write("Cabin2 contains " + Cabin2 + " ");
      } else{
      edit.write("Cabin2 is empty ");
      }
      if(Cabin3.size() > 0){
      edit.write("Cabin3 contains " + Cabin3 + " ");
      } else{
      edit.write("Cabin3 is empty ");
      }
      if(Cabin4.size() > 0){
      edit.write("Cabin4 contains " + Cabin4 + " ");
      } else{
      edit.write("Cabin4 is empty ");
      }
      if(Cabin5.size() > 0){
      edit.write("Cabin5 contains " + Cabin5 + " ");
      } else{
      edit.write("Cabin5 is empty ");
      }
      if(Cabin6.size() > 0){
      edit.write("Cabin6 contains " + Cabin6 + " ");
      } else{
      edit.write("Cabin6 is empty");
      }
      if(Cabin7.size() > 0){
      edit.write("Cabin7 contains " + Cabin7 + " ");
      } else{
      edit.write("Cabin7 is empty ");
      }
      if(Cabin8.size() > 0){
      edit.write("Cabin8 contains " + Cabin8 + " ");
      } else{
      edit.write("Cabin8 is empty ");
      }
      if(Cabin9.size() > 0){
      edit.write("Cabin9 contains " + Cabin9 + " ");
      } else{
      edit.write("Cabin9 is empty ");
      }
      if(Cabin10.size() > 0){
      edit.write("Cabin10 contains " + Cabin10 + " ");
      } else{
      edit.write("Cabin10 is empty ");
      }
      if(Cabin11.size() > 0){
      edit.write("Cabin11 contains " + Cabin11 + " ");
      } else{
      edit.write("Cabin11 is empty ");
      }
      if(Cabin12.size() > 0){
      edit.write("Cabin12 contains " + Cabin12 + " ");
      } else{
      edit.write("Cabin12 is empty ");
      }
           
      edit.close();
      System.out.println("Successfully wrote to the file.");
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
    }
    
    public static void LoadFile(){
        try {
      File myObj = new File(FileName + ".txt");
      Scanner myReader = new Scanner(myObj);
      while (myReader.hasNextLine()) {
        String data = myReader.nextLine();
        System.out.println(data);
      }
      myReader.close();
    } catch (FileNotFoundException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
    }
    
    public static void NameOrder(){
        ArrayList<Passengers> allpassengers = new ArrayList<>();
        allpassengers.addAll(Cabin1);
        allpassengers.addAll(Cabin2);
        allpassengers.addAll(Cabin3);
        allpassengers.addAll(Cabin4);
        allpassengers.addAll(Cabin5);
        allpassengers.addAll(Cabin6);
        allpassengers.addAll(Cabin7);
        allpassengers.addAll(Cabin8);
        allpassengers.addAll(Cabin9);
        allpassengers.addAll(Cabin10);
        allpassengers.addAll(Cabin11);
        allpassengers.addAll(Cabin12);
        if(allpassengers.size() > 0){
        Collections.sort(allpassengers, Passengers.PassnameComparator);
        System.out.println(allpassengers);
        }
        else{
        System.out.println("There are no passengers in any cabin");
        }
    }
    
    
    public static void FindCustomer() {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter  the first name of the customer you wish to find:");
        String firstname = input.next();

        System.out.print("Enter the last name of the customer you wish to find:");
        String surname1 = input.next();

        for (int i = 0; i < Cabin1.size(); i++) {
            String fname = Cabin1.get(i).getFirstName().toLowerCase();
            String sname = Cabin1.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has been found in Cabin1");
            }
        }
        for (int i = 0; i < Cabin2.size(); i++) {
            String fname = Cabin2.get(i).getFirstName().toLowerCase();
            String sname = Cabin2.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has been found in Cabin2");
            }

        }

        for (int i = 0; i < Cabin3.size(); i++) {
            String fname = Cabin3.get(i).getFirstName().toLowerCase();
            String sname = Cabin3.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has been found in Cabin3");
            }

        }
        for(int i = 0; i < Cabin4.size(); i++) {
            String fname = Cabin4.get(i).getFirstName().toLowerCase();
            String sname = Cabin4.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has been found in Cabin4");
            }

        }

        for(int i = 0; i < Cabin5.size(); i++) {
            String fname = Cabin5.get(i).getFirstName().toLowerCase();
            String sname = Cabin5.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has been found in Cabin5");
            }

        }
        for(int i = 0; i < Cabin6.size(); i++) {
            String fname = Cabin6.get(i).getFirstName().toLowerCase();
            String sname = Cabin6.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has been found in Cabin6");
            }
        }
        for(int i = 0; i < Cabin7.size(); i++) {
            String fname = Cabin7.get(i).getFirstName().toLowerCase();
            String sname = Cabin7.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has been found in Cabin7");
            }

        }
        for(int i = 0; i < Cabin8.size(); i++) {
            String fname = Cabin8.get(i).getFirstName().toLowerCase();
            String sname = Cabin8.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has been found in Cabin8");
            }

        }
        for(int i = 0; i < Cabin9.size(); i++) {
            String fname = Cabin9.get(i).getFirstName().toLowerCase();
            String sname = Cabin9.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has been found in Cabin9");
            }

        }
        for(int i = 0; i < Cabin10.size(); i++) {
            String fname = Cabin10.get(i).getFirstName().toLowerCase();
            String sname = Cabin10.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has been found in Cabin10");
            }

        }
        for(int i = 0; i < Cabin11.size(); i++) {
            String fname = Cabin11.get(i).getFirstName().toLowerCase();
            String sname = Cabin11.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has been found in Cabin11");
            }

        }
        for(int i = 0; i < Cabin12.size(); i++) {
            String fname = Cabin12.get(i).getFirstName().toLowerCase();
            String sname = Cabin12.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has been found in Cabin12");
            }

        }

    }
    
    
    public static void CustomerExpenses() {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter  the first name of the customer whose expenses you wish to find:");
        String firstname = input.next();

        System.out.print("Enter the last name of the customer whose expenses you wish to find:");
        String surname1 = input.next();

        for (int i = 0; i < Cabin1.size(); i++) {
            String fname = Cabin1.get(i).getFirstName().toLowerCase();
            String sname = Cabin1.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            double expenses1 = Cabin1.get(i).getExpenses();
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has a total of " + expenses1 + " as their expenses.");
            }
        }
        for (int i = 0; i < Cabin2.size(); i++) {
            String fname = Cabin2.get(i).getFirstName().toLowerCase();
            String sname = Cabin2.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            double expenses1 = Cabin2.get(i).getExpenses();
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has a total of " + expenses1 + " as their expenses.");
            }

        }

        for (int i = 0; i < Cabin3.size(); i++) {
            String fname = Cabin3.get(i).getFirstName().toLowerCase();
            String sname = Cabin3.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            double expenses1 = Cabin3.get(i).getExpenses();
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has a total of " + expenses1 + " as their expenses.");
            }

        }
        for(int i = 0; i < Cabin4.size(); i++) {
            String fname = Cabin4.get(i).getFirstName().toLowerCase();
            String sname = Cabin4.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            double expenses1 = Cabin4.get(i).getExpenses();
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has a total of " + expenses1 + " as their expenses.");
            }

        }

        for(int i = 0; i < Cabin5.size(); i++) {
            String fname = Cabin5.get(i).getFirstName().toLowerCase();
            String sname = Cabin5.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            double expenses1 = Cabin5.get(i).getExpenses();
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has a total of " + expenses1 + " as their expenses.");
            }

        }
        for(int i = 0; i < Cabin6.size(); i++) {
            String fname = Cabin6.get(i).getFirstName().toLowerCase();
            String sname = Cabin6.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            double expenses1 = Cabin6.get(i).getExpenses();
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has a total of " + expenses1 + " as their expenses.");
            }
        }
        for(int i = 0; i < Cabin7.size(); i++) {
            String fname = Cabin7.get(i).getFirstName().toLowerCase();
            String sname = Cabin7.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            double expenses1 = Cabin7.get(i).getExpenses();
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has a total of " + expenses1 + " as their expenses.");
            }

        }
        for(int i = 0; i < Cabin8.size(); i++) {
            String fname = Cabin8.get(i).getFirstName().toLowerCase();
            String sname = Cabin8.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            double expenses1 = Cabin8.get(i).getExpenses();
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has a total of " + expenses1 + " as their expenses.");
            }

        }
        for(int i = 0; i < Cabin9.size(); i++) {
            String fname = Cabin9.get(i).getFirstName().toLowerCase();
            String sname = Cabin9.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            double expenses1 = Cabin9.get(i).getExpenses();
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has a total of " + expenses1 + " as their expenses.");
            }

        }
        for(int i = 0; i < Cabin10.size(); i++) {
            String fname = Cabin10.get(i).getFirstName().toLowerCase();
            String sname = Cabin10.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            double expenses1 = Cabin10.get(i).getExpenses();
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has a total of " + expenses1 + " as their expenses.");
            }

        }
        for(int i = 0; i < Cabin11.size(); i++) {
            String fname = Cabin11.get(i).getFirstName().toLowerCase();
            String sname = Cabin11.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            double expenses1 = Cabin11.get(i).getExpenses();
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has a total of " + expenses1 + " as their expenses.");
            }
        }
        for(int i = 0; i < Cabin12.size(); i++) {
            String fname = Cabin12.get(i).getFirstName().toLowerCase();
            String sname = Cabin12.get(i).getSurname().toLowerCase();
            String CAfullname = firstname + surname1;
            String fullname = fname + sname;
            double expenses1 = Cabin12.get(i).getExpenses();
            if (CAfullname.toLowerCase().equals(fullname)) {
                System.out.println("Customer " + fullname + " Has a total of " + expenses1 + " as their expenses.");
            }

        }

    }
    
    
    
    
}


